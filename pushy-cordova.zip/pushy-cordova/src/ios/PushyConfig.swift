//
//  PushyConfig.swift
//  Pushy
//
//  Created by Pushy on 10/8/16.
//  Copyright © 2016 Pushy. All rights reserved.
//

import Foundation

public class PushyConfig {
    // API hostname 
    static var apiBaseUrl = "https://api.pushy.me"
}
