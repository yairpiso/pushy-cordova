package me.pushy.sdk.cordova.internal.config;

public class PushyIntentExtras {
    public static final String NOTIFICATION_CLICKED = "_pushyNotificationClicked";
    public static final String NOTIFICATION_PAYLOAD = "_pushyNotificationPayload";
}
